import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        System.out.println("Enter your full age");
        int userAge = scn.nextInt();
        int compAge = scn.nextInt();

        System.out.println(" Enter your weight ");
        int userWeight = scn.nextInt();
        int compWeight = scn.nextInt();

        System.out.println(" Enter your Name ");
        String userName = scn.nextLine();
        String compName = scn.nextLine();



        System.out.printf(" Dear , %s ! At your %d  are dear to us , like %d kilograms of gold " , userName , userAge , userWeight );






    }
}